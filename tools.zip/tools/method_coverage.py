"""Utility to summarize coverage.py branch data per method."""

from __future__ import annotations

import argparse
import ast
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from xml.etree import ElementTree as ET


@dataclass
class MethodRange:
    name: str
    start: int
    end: int


@dataclass
class ClassBlock:
    name: str
    methods: List[MethodRange]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Summarize method-level branch coverage from coverage.xml"
    )
    parser.add_argument(
        "--coverage",
        default="coverage.xml",
        help="Path to coverage XML generated via --cov-report=xml (default: coverage.xml)",
    )
    target_group = parser.add_mutually_exclusive_group(required=True)
    target_group.add_argument(
        "--file",
        help="Specific Python file to analyze (e.g., src/interfaces/pages/.../zone_manager.py)",
    )
    target_group.add_argument(
        "--path-prefix",
        action="append",
        help="Process every file whose coverage filename starts with this prefix. Repeatable.",
    )
    parser.add_argument(
        "--class-name",
        action="append",
        help="Only report these class names (valid only with --file). Repeatable.",
    )
    return parser.parse_args()


def normalize_filename(name: str) -> str:
    """Convert filesystem or coverage paths to a canonical form without leading ./ or src/."""
    norm = str(Path(name).as_posix()).lstrip("./")
    return norm[4:] if norm.startswith("src/") else norm


def collect_branch_maps(coverage_xml: Path) -> Dict[str, Dict[int, Tuple[int, int]]]:
    tree = ET.parse(coverage_xml)
    root = tree.getroot()
    file_map: Dict[str, Dict[int, Tuple[int, int]]] = {}
    for class_elem in root.findall(".//class"):
        filename = class_elem.get("filename")
        if not filename:
            continue
        normalized = normalize_filename(filename)
        branch_map = file_map.setdefault(normalized, {})
        lines = class_elem.find("lines")
        if lines is None:
            continue
        for line in lines.findall("line"):
            cond = line.get("condition-coverage")
            if not cond or "(" not in cond or "/" not in cond:
                continue
            counts = cond.split("(", 1)[1].split(")", 1)[0]
            covered_str, total_str = counts.split("/", 1)
            covered = int(covered_str)
            total = int(total_str)
            if total == 0:
                continue
            line_no = int(line.get("number"))
            existing = branch_map.get(line_no)
            if existing:
                covered = max(existing[0], covered)
                total = max(existing[1], total)
            branch_map[line_no] = (covered, total)
    return file_map


def determine_targets(
    args: argparse.Namespace, available_files: Sequence[str]
) -> List[str]:
    if args.file:
        return [normalize_filename(args.file)]
    prefixes = [normalize_filename(p) for p in (args.path_prefix or ())]
    matches = sorted(
        {
            filename
            for filename in available_files
            if any(filename.startswith(prefix) for prefix in prefixes)
        }
    )
    if not matches:
        raise SystemExit(
            f"No files in coverage.xml match prefixes: {', '.join(args.path_prefix or [])}"
        )
    return matches


def resolve_source_path(canonical: str) -> Path:
    candidate = Path(canonical)
    if candidate.exists():
        return candidate
    alt = Path("src") / canonical
    if alt.exists():
        return alt
    raise SystemExit(
        f"Source file '{canonical}' not found (checked '{canonical}' and 'src/{canonical}')"
    )


def extract_method_blocks(source_path: Path) -> List[ClassBlock]:
    module = ast.parse(source_path.read_text(encoding="utf-8"))
    blocks: List[ClassBlock] = []

    def collect_methods(nodes: Iterable[ast.stmt]) -> List[MethodRange]:
        methods: List[MethodRange] = []
        for node in nodes:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", node.lineno)
                methods.append(MethodRange(node.name, node.lineno, end))
        return methods

    module_methods = collect_methods(module.body)
    if module_methods:
        blocks.append(ClassBlock("<module>", module_methods))

    for node in module.body:
        if isinstance(node, ast.ClassDef):
            methods = collect_methods(node.body)
            if methods:
                blocks.append(ClassBlock(node.name, methods))

    return blocks


def summarize(branch_map: Dict[int, Tuple[int, int]], methods: List[MethodRange]):
    rows = []
    total_branch = 0
    total_cover = 0
    for method in methods:
        hit = 0
        total = 0
        for line_no, (covered, branch_total) in branch_map.items():
            if method.start <= line_no <= method.end:
                hit += covered
                total += branch_total
        missing = total - hit
        total_branch += total
        total_cover += hit
        coverage = "-" if total == 0 else f"{(hit / total) * 100:.0f}%"
        rows.append(
            {
                "name": method.name,
                "branch": total,
                "cover": hit,
                "missing": missing,
                "coverage": coverage,
            }
        )
    summary = None
    if total_branch:
        summary = {
            "name": "Total",
            "branch": total_branch,
            "cover": total_cover,
            "missing": total_branch - total_cover,
            "coverage": f"{(total_cover / total_branch) * 100:.0f}%",
        }
    return rows, summary


def format_markdown(rows, summary):
    header = (
        "| Method | Branch | Cover | Missing | Coverage |\n"
        "| --- | ---: | ---: | ---: | ---: |\n"
    )
    body = "\n".join(
        f"| {row['name']} | {row['branch']} | {row['cover']} | {row['missing']} | {row['coverage']} |"
        for row in rows
    )
    if summary:
        body += (
            f"\n| {summary['name']} | {summary['branch']} | {summary['cover']} | "
            f"{summary['missing']} | {summary['coverage']} |"
        )
    return header + body


def filter_blocks(
    blocks: List[ClassBlock], class_filters: Optional[Sequence[str]]
) -> List[ClassBlock]:
    if not class_filters:
        return blocks
    filters = set(class_filters)
    return [block for block in blocks if block.name in filters]


def main():
    args = parse_args()
    if args.class_name and not args.file:
        raise SystemExit("--class-name can only be used together with --file")

    branch_maps = collect_branch_maps(Path(args.coverage))
    targets = determine_targets(args, list(branch_maps.keys()))

    outputs: List[str] = []
    for canonical in targets:
        source_path = resolve_source_path(canonical)
        branch_map = branch_maps.get(canonical, {})
        blocks = filter_blocks(extract_method_blocks(source_path), args.class_name)
        if not blocks:
            continue
        for block in blocks:
            rows, summary = summarize(branch_map, block.methods)
            if not rows:
                continue
            title = f"### {canonical} — {block.name}"
            outputs.append(f"{title}\n{format_markdown(rows, summary)}")

    if outputs:
        print("\n\n".join(outputs))
    else:
        print("No matching methods with branch data were found.")


if __name__ == "__main__":
    sys.exit(main())
