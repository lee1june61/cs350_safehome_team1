"""Create class-level coverage tables using coverage.json line data.

Example usage:
    # Regenerate coverage.json then build a Markdown report for one module
    pytest --cov=. --cov-report=json
    python tools/class_coverage_json.py --file interfaces/pages/safehome_mode_configure_page/safehome_mode_configure_page.py

    # All files under a prefix, write Markdown to a file, and emit JSON too
    python tools/class_coverage_json.py --path-prefix src/interfaces/pages/ --output class_coverage.md

Assumes `pytest --cov=. --cov-report=json` has already been executed.
"""

from __future__ import annotations

import argparse
import ast
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple


@dataclass
class ClassInfo:
    name: str
    start: int
    end: int


class ClassCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.stack: List[str] = []
        self.classes: List[ClassInfo] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        start = node.lineno
        end = getattr(node, "end_lineno", None)
        if end is None:
            if node.body:
                end_node = node.body[-1]
                end = getattr(end_node, "end_lineno", getattr(end_node, "lineno", start))
            else:
                end = start
        qual = ".".join(self.stack + [node.name]) if self.stack else node.name
        self.classes.append(ClassInfo(qual, start, end))
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Summarize class-level coverage metrics using coverage.json"
    )
    parser.add_argument(
        "--coverage",
        default="coverage.json",
        help="Path to coverage.json (default: coverage.json)",
    )
    parser.add_argument(
        "--file",
        help="Specific file to analyze (relative to repo root, e.g. src/module.py)",
    )
    parser.add_argument(
        "--path-prefix",
        action="append",
        help="Include every coverage entry whose relative path starts with this prefix. Repeatable.",
    )
    parser.add_argument(
        "--output",
        help="Optional file path to write the report (Markdown or JSON).",
    )
    parser.add_argument(
        "--format",
        choices=("table", "json"),
        default="table",
        help="Output format (default: table/Markdown).",
    )
    return parser.parse_args()


def load_coverage(coverage_path: Path) -> Dict[str, dict]:
    if not coverage_path.exists():
        raise SystemExit(
            f"{coverage_path} not found. Run 'pytest --cov=. --cov-report=json' first."
        )
    data = json.loads(coverage_path.read_text(encoding="utf-8"))
    files = data.get("files")
    if not isinstance(files, dict):
        raise SystemExit("Invalid coverage.json: missing 'files' section.")
    return files


def resolve_source_path(raw: str) -> Path:
    raw_path = Path(raw)
    candidates = [raw_path]
    if not raw_path.is_absolute():
        if not raw_path.parts or raw_path.parts[0] != "src":
            candidates.append(Path("src") / raw_path)
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    text = ", ".join(str(c) for c in candidates)
    raise SystemExit(f"Source file not found. Tried: {text}")


def match_file_entry(files: Dict[str, dict], source_path: Path) -> dict:
    source_abs = source_path.resolve()
    for recorded_path, metadata in files.items():
        if Path(recorded_path).resolve() == source_abs:
            return metadata
    raise SystemExit(f"No coverage data found for {source_path}.")


def relative_label(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return path.as_posix()


def should_include(rel_path: str, prefixes: Sequence[str] | None) -> bool:
    if not prefixes:
        return True
    unixy = rel_path.replace("\\", "/")
    return any(unixy.startswith(prefix) for prefix in prefixes)


def gather_targets(
    coverage_files: Dict[str, dict], args: argparse.Namespace, repo_root: Path
) -> List[Tuple[Path, str, dict]]:
    entries: List[Tuple[Path, str, dict]] = []
    if args.file:
        source_path = resolve_source_path(args.file)
        meta = match_file_entry(coverage_files, source_path)
        rel = relative_label(source_path, repo_root)
        entries.append((source_path, rel, meta))
        return entries

    prefixes = [p.replace("\\", "/") for p in args.path_prefix] if args.path_prefix else None
    for recorded_path, metadata in coverage_files.items():
        resolved = Path(recorded_path).resolve()
        rel = relative_label(resolved, repo_root)
        if should_include(rel, prefixes):
            entries.append((resolved, rel, metadata))
    return sorted(entries, key=lambda item: item[1])


def collect_classes(source_path: Path) -> List[ClassInfo]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    collector = ClassCollector()
    collector.visit(tree)
    if not collector.classes:
        total_lines = len(source_path.read_text(encoding="utf-8").splitlines())
        return [ClassInfo("<module>", 1, total_lines)]
    return collector.classes


def summarize_class(info: ClassInfo, executed: set[int], missing: set[int]) -> Tuple[int, int, int]:
    relevant = {
        line
        for line in range(info.start, info.end + 1)
        if (line in executed or line in missing)
    }
    if not relevant:
        return 0, 0, 0
    covered = len(relevant & executed)
    missed = len(relevant & missing)
    total = covered + missed
    return total, covered, missed


def format_table(rows: List[dict]) -> str:
    header = (
        "| Class | Total | Covered | Missing | Coverage |\n"
        "| --- | ---: | ---: | ---: | ---: |"
    )
    lines = [
        f"| {row['name']} | {row['total']} | {row['covered']} | {row['missing']} | {row['coverage']} |"
        for row in rows
    ]
    return "\n".join([header] + lines)


def main() -> None:
    args = parse_args()
    coverage_files = load_coverage(Path(args.coverage))
    repo_root = Path.cwd().resolve()

    targets = gather_targets(coverage_files, args, repo_root)
    sections: List[str] = []
    json_blob: Dict[str, List[dict]] = {}

    for source_path, rel_path, meta in targets:
        if not source_path.exists():
            continue
        executed = set(meta.get("executed_lines", []))
        missing = set(meta.get("missing_lines", []))
        rows: List[dict] = []
        for cls in collect_classes(source_path):
            total, covered, missed = summarize_class(cls, executed, missing)
            if total == 0:
                continue
            pct = f"{(covered / total) * 100:.0f}%"
            rows.append(
                {
                    "name": cls.name,
                    "total": total,
                    "covered": covered,
                    "missing": missed,
                    "coverage": pct,
                }
            )
        if not rows:
            continue
        if args.format == "json":
            json_blob[rel_path] = rows
        else:
            sections.append(f"### {rel_path}\n{format_table(rows)}")

    if args.format == "json":
        output = json.dumps(json_blob, indent=2)
    else:
        output = "\n\n".join(sections) if sections else "No classes with measurable coverage."

    print(output)

    if args.output:
        Path(args.output).write_text(output + "\n", encoding="utf-8")
        print(f"\nWrote report to {args.output}")


if __name__ == "__main__":
    main()


