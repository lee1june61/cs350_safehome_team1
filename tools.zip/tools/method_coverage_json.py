"""Generate method-level coverage summaries from coverage.json.

Usage examples:
    # Single file
    python tools/method_coverage_json.py --file interfaces/pages/safety_zone_page/zone_manager.py

    # All files under a directory prefix
    python tools/method_coverage_json.py --path-prefix interfaces/pages/safety_zone_page/

    # Entire project and write to a text file
    python tools/method_coverage_json.py --output coverage_methods.txt

Assumes coverage.json was produced via:
    pytest --cov=. --cov-report=json
"""

from __future__ import annotations

import argparse
import ast
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


@dataclass
class MethodInfo:
    name: str
    start: int
    end: int


class MethodCollector(ast.NodeVisitor):
    """Collect fully qualified function / method names with their line ranges."""

    def __init__(self) -> None:
        self.stack: List[str] = []
        self.methods: List[MethodInfo] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._add_method(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._add_method(node)
        self.generic_visit(node)

    def _add_method(self, node: ast.AST) -> None:
        end_lineno = getattr(node, "end_lineno", None)
        if end_lineno is None:
            # Fallback: best-effort using last body node
            if getattr(node, "body", []):
                end_lineno = node.body[-1].lineno
            else:
                end_lineno = node.lineno
        qual = ".".join(self.stack + [node.name]) if self.stack else node.name  # type: ignore[attr-defined]
        self.methods.append(MethodInfo(qual, node.lineno, end_lineno))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Summarize method-level line coverage using coverage.json output"
    )
    parser.add_argument(
        "--coverage",
        default="coverage.json",
        help="Path to coverage.json (default: coverage.json)",
    )
    parser.add_argument(
        "--file",
        help="Source file to analyze (relative to repo root, e.g. src/interfaces/.../file.py)",
    )
    parser.add_argument(
        "--path-prefix",
        action="append",
        help="Process every coverage entry whose relative path starts with this prefix. Repeatable.",
    )
    parser.add_argument(
        "--output",
        help="Optional path to write the resulting table(s). Printed to stdout regardless.",
    )
    parser.add_argument(
        "--format",
        choices=("table", "json"),
        default="table",
        help="Output format (default: table)",
    )
    return parser.parse_args()


def load_coverage(coverage_path: Path) -> Dict[str, dict]:
    if not coverage_path.exists():
        raise SystemExit(
            f"{coverage_path} not found. Run 'pytest --cov=. --cov-report=json' first."
        )
    data = json.loads(coverage_path.read_text(encoding="utf-8"))
    files = data.get("files")
    if not isinstance(files, dict):
        raise SystemExit("Invalid coverage.json: missing 'files' section.")
    return files


def match_file_entry(files: Dict[str, dict], target: Path) -> dict:
    target_abs = target.resolve()
    for recorded_path, metadata in files.items():
        if Path(recorded_path).resolve() == target_abs:
            return metadata
    raise SystemExit(f"Coverage data for '{target}' not found in coverage.json.")


def resolve_source_path(raw: str) -> Path:
    raw_path = Path(raw)
    candidates = [raw_path]
    if not raw_path.is_absolute():
        if not raw_path.parts or raw_path.parts[0] != "src":
            candidates.append(Path("src") / raw_path)
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    search_list = ", ".join(str(c) for c in candidates)
    raise SystemExit(f"Source file not found. Tried: {search_list}")


def collect_methods(source_path: Path) -> List[MethodInfo]:
    if not source_path.exists():
        raise SystemExit(f"Source file '{source_path}' does not exist.")
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    collector = MethodCollector()
    collector.visit(tree)
    return collector.methods


def summarize_method(method: MethodInfo, executed: set[int], missing: set[int]) -> Tuple[int, int, int]:
    relevant_lines = {
        line
        for line in range(method.start, method.end + 1)
        if (line in executed or line in missing)
    }
    if not relevant_lines:
        return 0, 0, 0
    covered = len(relevant_lines & executed)
    missed = len(relevant_lines & missing)
    total = covered + missed
    return total, covered, missed


def format_table(rows: Sequence[dict]) -> str:
    header = (
        "| Method | Total | Covered | Missing | Coverage |\n"
        "| --- | ---: | ---: | ---: | ---: |"
    )
    lines = [
        f"| {row['name']} | {row['total']} | {row['covered']} | {row['missing']} | {row['coverage']} |"
        for row in rows
    ]
    return "\n".join([header] + lines)


def main() -> None:
    args = parse_args()
    coverage_files = load_coverage(Path(args.coverage))
    repo_root = Path.cwd().resolve()

    targets = gather_targets(coverage_files, args, repo_root)

    sections: List[str] = []
    json_output: Dict[str, List[dict]] = {}

    for source_path, rel_path, meta in targets:
        if not source_path.exists():
            continue
        executed = set(meta.get("executed_lines", []))
        missing = set(meta.get("missing_lines", []))
        rows: List[dict] = []
        for method in collect_methods(source_path):
            total, covered, missed = summarize_method(method, executed, missing)
            if total == 0:
                continue
            pct = f"{(covered / total) * 100:.1f}%"
            rows.append(
                {
                    "name": method.name,
                    "total": total,
                    "covered": covered,
                    "missing": missed,
                    "coverage": pct,
                }
            )
        if not rows:
            continue
        if args.format == "json":
            json_output[rel_path] = rows
        else:
            sections.append(f"### {rel_path}\n{format_table(rows)}")

    if args.format == "json":
        output_text = json.dumps(json_output, indent=2)
    else:
        output_text = "\n\n".join(sections) if sections else "No matching methods found."

    print(output_text)

    if args.output:
        Path(args.output).write_text(output_text + "\n", encoding="utf-8")
        print(f"\nWrote report to {args.output}")


def relative_label(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return path.as_posix()


def should_include(rel_path: str, prefixes: Sequence[str] | None) -> bool:
    if not prefixes:
        return True
    normalized = rel_path.replace("\\", "/")
    return any(normalized.startswith(prefix) for prefix in prefixes)


def gather_targets(
    coverage_files: Dict[str, dict], args: argparse.Namespace, repo_root: Path
) -> List[Tuple[Path, str, dict]]:
    entries: List[Tuple[Path, str, dict]] = []
    if args.file:
        source_path = resolve_source_path(args.file)
        meta = match_file_entry(coverage_files, source_path)
        rel = relative_label(source_path, repo_root)
        entries.append((source_path, rel, meta))
        return entries

    prefixes = None
    if args.path_prefix:
        prefixes = [p.replace("\\", "/") for p in args.path_prefix]

    for recorded_path, metadata in coverage_files.items():
        resolved = Path(recorded_path).resolve()
        rel = relative_label(resolved, repo_root)
        if should_include(rel, prefixes):
            entries.append((resolved, rel, metadata))
    return sorted(entries, key=lambda item: item[1])


if __name__ == "__main__":
    main()


